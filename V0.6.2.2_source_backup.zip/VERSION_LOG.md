\# PLC数字工程师项目版本记录



\## V0.6.1 - 已封版



封版时间：2026-05-08



\### 核心能力



\- 整机中文需求解析为多工站 station\_configs

\- 支持 S1 / S2 多工站识别

\- 支持多工站 ZIP 工程包生成

\- 支持 manifest.json 追踪清单

\- 支持 validation\_report.txt 自动校验报告

\- 支持 configs 目录输出

\- 支持 template\_source 模板追踪

\- 支持 S1 / S2 工站 ST 文件生成

\- 支持报警 / 超时 / 复位基础逻辑



\### 验收结果



\- ZIP 基础结构检查通过

\- V0.6.1 逻辑检查通过

\- V0.6.1 最终验收通过

\- 已生成源码备份：V0.6.1\_source\_backup.zip



\### 下一版本



V0.6.2：整机主流程 + 多工站互锁增强

\## V0.6.2 - 已封版



封版时间：2026-05-08



\### 核心能力



\- 基于 V0.6.1 多工站工程包自动升级为 V0.6.2 工程包

\- 新增整机主流程 ST：04\_Machine\_Auto\_Main\_Generated.st

\- 新增 HMI 变量清单：HMI\_Variable\_List.csv

\- 新增多工站顺序互锁

\- 支持 S1 完成后允许 S2 执行

\- 支持最后工站完成后整机完成

\- 支持任意工站报警汇总到整机报警

\- 支持 Reset 统一复位所有工站

\- 新增 configs/v062\_station\_chain.json

\- 自动更新 manifest.json

\- 自动更新 validation\_report.txt



\### 验收结果



\- V0.6.2 ZIP 文件结构检查通过

\- 整机主流程 ST 检查通过

\- HMI 变量清单检查通过

\- validation\_report V0.6.2 信息检查通过



\### 当前生成结果



\- AI\_Device\_Project\_Package\_V06\_V0.6.2.zip



\### 下一版本



V0.6.2.1：把 V0.6.2 外挂升级逻辑正式合并进主工程生成器

\## V0.6.2.1 - 已封版



封版时间：2026-05-08



\### 核心能力



\- 将 V0.6.2 外挂升级能力正式合并进主工程生成器

\- 新增 machine\_main\_generator.py

\- 新增 hmi\_variable\_generator.py

\- multi\_station\_project\_generator.py 直接生成整机主流程 ST

\- multi\_station\_project\_generator.py 直接生成 HMI 变量清单

\- 自动生成 04\_Machine\_Auto\_Main\_Generated.st

\- 自动生成 HMI\_Variable\_List.csv

\- 自动生成 configs/v062\_station\_chain.json

\- manifest.json 写入 V0.6.2.1 版本信息

\- validation\_report.txt 写入 V0.6.2.1 验收信息



\### 验收结果



\- Python 编译检查通过

\- 主生成器直接生成 ZIP 通过

\- V0.6.2.1 集成验收通过



\### 当前稳定输出



\- output/AI\_Device\_Project\_Package\_V06.zip



\### 下一版本



V0.6.2.2：Streamlit 界面端验收与版本显示同步

